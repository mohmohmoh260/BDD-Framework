package workDirectory.stepDefinitions;

import builds.actions.MobileActions;
import builds.utilities.BrowserInstance;
import io.cucumber.java.*;
import builds.actions.BrowserActions;

public class Hooks{
    private Scenario scenario;

    @BeforeStep
    public void setScenario(Scenario scenario) {
        this.scenario=scenario;
    }

    @AfterStep
    public void takeScreenshotIfFailed(Scenario scenario) {
        if (scenario.isFailed()) {
            MobileActions mobileActions = new MobileActions();
            BrowserInstance browserInstance = new BrowserInstance();
            BrowserActions browserActions = new BrowserActions();
            if (browserInstance.getWebDriver()!=null) {
                browserActions.screenshot(scenario);
            } else {
                mobileActions.screenshot();
            }
        }
    }

    public Scenario getScenario() {
        return this.scenario;
    }
}
