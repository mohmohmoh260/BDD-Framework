package builds.snippetClasses;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GherkinStepRunner {
    private final List<Class<?>> stepDefinitionClasses;
    public static final ThreadLocal<DataTable> dataTableHolder = new ThreadLocal<>();

    public GherkinStepRunner(List<Class<?>> stepDefinitionClasses) {
        this.stepDefinitionClasses = stepDefinitionClasses;
    }

    public void executeStep(String gherkinStep) throws Exception {
        String cleanedStep = gherkinStep.replaceAll("^(Given|When|Then|And)\\s+", "");

        for (Class<?> clazz : stepDefinitionClasses) {
            for (Method method : clazz.getDeclaredMethods()) {
                String annotationValue = getCucumberAnnotationValue(method);
                if (annotationValue == null) continue;

                Pattern pattern = buildRegexPattern(annotationValue);
                Matcher matcher = pattern.matcher(cleanedStep);

                if (matcher.matches()) {
                    Object instance = clazz.getDeclaredConstructor().newInstance();

                    // Extract parameters
                    Class<?>[] parameterTypes = method.getParameterTypes();
                    Object[] params = new Object[matcher.groupCount()];

                    // Inside GherkinStepRunner.executeStep()
                    if (params.length > 0 && params[params.length - 1] instanceof DataTable) {
                        dataTableHolder.set((DataTable) params[params.length - 1]);
                        System.out.println("Stored DataTable: " + params[params.length - 1]);
                    }

                    for (int i = 0; i < matcher.groupCount(); i++) {
                        params[i] = convertParameter(parameterTypes[i], matcher.group(i + 1));
                    }

                    // Handle DataTable if required
                    if (method.getParameterCount() == matcher.groupCount() + 1 && parameterTypes[matcher.groupCount()].equals(DataTable.class)) {
                        DataTable emptyTable = DataTable.create(Collections.emptyList());
                        params = appendDataTable(params, emptyTable);
                        dataTableHolder.set(emptyTable); // Store DataTable for later retrieval
                    }

                    // Store DataTable if it is passed as parameter
                    if (params.length > 0 && params[params.length - 1] instanceof DataTable) {
                        dataTableHolder.set((DataTable) params[params.length - 1]);
                    }

                    // Invoke the method
                    method.invoke(instance, params);
                    return;
                }
            }
        }
        throw new NoSuchMethodException("No matching step definition found for: " + gherkinStep);
    }

    private String getCucumberAnnotationValue(Method method) {
        if (method.isAnnotationPresent(Given.class)) return method.getAnnotation(Given.class).value();
        if (method.isAnnotationPresent(When.class)) return method.getAnnotation(When.class).value();
        if (method.isAnnotationPresent(Then.class)) return method.getAnnotation(Then.class).value();
        if (method.isAnnotationPresent(And.class)) return method.getAnnotation(And.class).value();
        return null;
    }

    private Pattern buildRegexPattern(String stepDefinition) {
        return Pattern.compile("^" + stepDefinition
                .replaceAll("\\{string\\}", "\"([^\"]*)\"")
                .replaceAll("\\{int\\}", "(\\d+)")
                .replaceAll("\\{double\\}", "([+-]?\\d*\\.\\d+)")
                .replaceAll("\\{long\\}", "(\\d+)")
                .replaceAll("\\{float\\}", "([+-]?\\d*\\.\\d+)")
                .replaceAll("\\{boolean\\}", "(true|false)")
                + "$");
    }

    private Object convertParameter(Class<?> type, String value) {
        if (type.equals(int.class) || type.equals(Integer.class)) return Integer.parseInt(value);
        if (type.equals(double.class) || type.equals(Double.class)) return Double.parseDouble(value);
        if (type.equals(long.class) || type.equals(Long.class)) return Long.parseLong(value);
        if (type.equals(float.class) || type.equals(Float.class)) return Float.parseFloat(value);
        if (type.equals(boolean.class) || type.equals(Boolean.class)) return Boolean.parseBoolean(value);
        return value;
    }

    private Object[] appendDataTable(Object[] original, DataTable dataTable) {
        Object[] newArray = new Object[original.length + 1];
        System.arraycopy(original, 0, newArray, 0, original.length);
        newArray[original.length] = dataTable;
        return newArray;
    }

    // Retrieve the stored DataTable in any step
    public static DataTable getStoredDataTable() {
        return dataTableHolder.get();
    }
}