package builds.extent;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {

    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private static final ThreadLocal<ExtentTest> nodeExtentTest = new ThreadLocal<>();
    private static final ExtentReports extent = new ExtentReports();

    static {
        com.aventstack.extentreports.reporter.ExtentSparkReporter spark = new ExtentSparkReporter("test-output/ExtentReport.html");
        extent.attachReporter(spark);
    }

    public static synchronized ExtentTest getExtentTest() {
        return extentTest.get();
    }

    public static synchronized ExtentTest getNodeExtentTest() {
        return nodeExtentTest.get();
    }

    public static synchronized void setExtentTest(ExtentTest test) {
        extentTest.set(test);
    }

    public static synchronized void setNodeExtentTest(ExtentTest test) {
        nodeExtentTest.set(test);
    }

    public static synchronized void removeNodeExtent(){
        nodeExtentTest.remove();
    }

    public static synchronized ExtentReports getInstance() {
        return extent;
    }

    public static synchronized void flush() {
        extent.flush();
    }
}