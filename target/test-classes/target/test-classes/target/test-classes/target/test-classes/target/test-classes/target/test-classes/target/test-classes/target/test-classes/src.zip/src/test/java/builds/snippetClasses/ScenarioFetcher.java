package builds.snippetClasses;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ScenarioFetcher {
    private static final Pattern SCENARIO_PATTERN = Pattern.compile("(?i)^(Scenario|Scenario Outline):\\s*(.*)");
    private static final Pattern STEP_PATTERN = Pattern.compile("(?i)^(Given|When|Then|And|But)\\s+(.+)");

    public HashMap<String, List<String>> getScenariosWithSteps() throws IOException {
        HashMap<String, List<String>> scenarioMap = new HashMap<>();
        List<Path> featureFiles = getFeatureFiles();

        for (Path featureFile : featureFiles) {
            extractScenariosAndSteps(featureFile, scenarioMap);
        }
        return scenarioMap;
    }

    private List<Path> getFeatureFiles() throws IOException {
        try (Stream<Path> paths = Files.walk(Paths.get("src/test/resources/Snippet"))) {
            return paths.filter(Files::isRegularFile)
                    .filter(path -> path.toString().endsWith(".feature"))
                    .collect(Collectors.toList());
        }
    }

    private void extractScenariosAndSteps(Path featureFile, HashMap<String, List<String>> scenarioMap) throws IOException {
        List<String> lines = Files.readAllLines(featureFile);
        String currentScenario = null;
        List<String> currentSteps = new ArrayList<>();

        for (String line : lines) {
            line = line.trim();
            Matcher scenarioMatcher = SCENARIO_PATTERN.matcher(line);
            Matcher stepMatcher = STEP_PATTERN.matcher(line);

            if (scenarioMatcher.matches()) {
                if (currentScenario != null) {
                    scenarioMap.put(currentScenario, new ArrayList<>(currentSteps));
                }
                currentScenario = scenarioMatcher.group(2);
                currentSteps.clear();
            } else if (stepMatcher.matches() && currentScenario != null) {
                currentSteps.add(line);
            }
        }

        if (currentScenario != null) {
            scenarioMap.put(currentScenario, currentSteps);
        }
    }
}