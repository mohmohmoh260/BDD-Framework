package workDirectory.stepDefinitions;

import builds.actions.MainActions;
import builds.extent.ExtentManager;
import builds.utilities.StepListener;
import com.aventstack.extentreports.ExtentTest;
import io.cucumber.java.*;

public class Hooks extends MainActions {

    private static final ThreadLocal<Scenario> currentScenario = new ThreadLocal<>();
    private static final ThreadLocal<String> stepName = new ThreadLocal<>();

    @Before
    public void beforeScenario(Scenario scenario){
        ExtentManager.getInstance().setSystemInfo("OS", System.getProperty("os.name"));
        ExtentTest extentTest = ExtentManager.getInstance().createTest(scenario.getName());
        ExtentManager.setExtentTest(extentTest);
    }

    @BeforeStep
    public void beforeStep(Scenario scenario) {
        currentScenario.set(scenario);
        setStepName(StepListener.gherkinStep.get());
        if(!toExecute.get()){
            currentScenario.get().log("⏭ Skipping test: "+ StepListener.gherkinStep.get());
        }
    }

    public Scenario getScenario() {
        return currentScenario.get();
    }

    public String getStepName(){
        return Hooks.stepName.get();
    }

    private void setStepName(String stepName){
        Hooks.stepName.set(stepName);
    }

    @AfterStep
    public void takeScreenshotEveryStep(Scenario scenario) {
        if(globalDeviceParameter.get().get(0).get("screenshotEveryStep").equals("true")){
            takeScreenshot();
        }if (scenario.isFailed()) {
            ExtentManager.getExtentTest().fail(StepListener.gherkinStep.get());
        } else {
            ExtentManager.getExtentTest().pass(StepListener.gherkinStep.get());
        }
    }

    @After
    public void afterScenario() {
        ExtentManager.flush();
    }
}
