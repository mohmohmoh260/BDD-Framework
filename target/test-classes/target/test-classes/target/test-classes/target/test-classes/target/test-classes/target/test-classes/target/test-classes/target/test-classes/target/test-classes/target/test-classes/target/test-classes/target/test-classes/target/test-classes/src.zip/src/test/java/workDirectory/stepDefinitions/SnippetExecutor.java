package workDirectory.stepDefinitions;

import builds.main.CucumberRun;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.FeatureWrapper;
import org.testng.annotations.*;

import java.util.Arrays;

public class SnippetExecutor {
    private final CucumberRun.TestRunner runner = new CucumberRun.TestRunner();

    public void runSpecificScenario(String scenarioName) {
        Object[][] scenarios = runner.scenarios(); // Fetch all scenarios
        System.out.println(Arrays.asList(scenarios));
        for (Object[] scenarioData : scenarios) {
            PickleWrapper pickleWrapper = (PickleWrapper) scenarioData[0];
            FeatureWrapper featureWrapper = (FeatureWrapper) scenarioData[1];

            if (pickleWrapper.getPickle().getName().equalsIgnoreCase(scenarioName)) {
                System.out.println("✅ Running: " + scenarioName);
                runner.runScenario(pickleWrapper, featureWrapper);
                return; // Stop after running the scenario
            }
        }
        System.out.println("⚠️ Scenario Not Found: " + scenarioName);
    }
}
