package builds.utilities;

public class Result {

    public static ThreadLocal<Boolean> success = ThreadLocal.withInitial(() -> Boolean.TRUE);
    public static ThreadLocal<String> message = ThreadLocal.withInitial(() -> "");

    public Result(boolean success, String message) {
        Result.success.set(success);
        Result.message.set(message);
    }

    public Boolean getSuccess() {
        return success.get();
    }

    public String getMessage() {
        return message.get();
    }

    public void statusCheck(){
        if(!getSuccess()){
            throw new RuntimeException(getMessage());
        }
    }
}