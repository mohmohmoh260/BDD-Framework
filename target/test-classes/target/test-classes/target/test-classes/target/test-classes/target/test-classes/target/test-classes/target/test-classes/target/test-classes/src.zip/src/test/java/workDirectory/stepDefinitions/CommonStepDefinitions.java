package workDirectory.stepDefinitions;

import builds.snippetClasses.GherkinStepRunner;
import builds.snippetClasses.ScenarioFetcher;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class CommonStepDefinitions extends CommonMethods{

    @And ("if {int} is bigger than {int}")
    public void ifNumberIsBiggerThanNumber(int firstValue, int secondValue){
       addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Arrays.asList(firstValue,secondValue));
    }

    @And ("if {int} is smaller than {int}")
    public void ifNumberIsSmallerThanNumber(int firstValue, int secondValue){
        addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Arrays.asList(firstValue,secondValue));
    }

    @And ("if {string} is not visible")
    public void ifElementIsNotVisible(String elementName){
        addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Collections.singletonList(elementName));
    }

    @And("end statement")
    public void endIfStatement(){
        endIf();
    }


    @And("I launch the browser and navigate to Google page with {string}")
    public void i_launch_the_browser_and_navigate_to_google_page_with(String browserType) {
        if(toExecute.get()){
            browserActions.browserSetup(browserType);
        }
    }

    @When("run snippet scenario {string}")
    public void runSnippetScenario(String scenarioName) throws Exception {
        if (toExecute.get()) {
            ScenarioFetcher fetcher = new ScenarioFetcher();
            HashMap<String, List<String>> scenarios = fetcher.getScenariosWithSteps();
            List<String> steps = scenarios.get(scenarioName);
            for (String step : steps) {
                CommonMethods.gherkinStepRunner.executeStep(step);
            }
        }
    }

    @Then("print from data table without header below")
    public void printFromDataTableWithoutHeaderBelow() {
        DataTable dataTable = GherkinStepRunner.dataTableHolder.get();
        System.out.println("Printing table without header...");
        System.out.println(dataTable.cells());
    }

    @Then("print from data table with header below")
    public void printFromDataTableWithHeaderBelow() {

    }
}
