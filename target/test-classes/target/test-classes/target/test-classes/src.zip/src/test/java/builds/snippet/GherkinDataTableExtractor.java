package builds.snippet;

import io.cucumber.datatable.DataTable;
import java.nio.file.*;
import java.io.IOException;
import java.util.*;

public class GherkinDataTableExtractor {

    public static List<Map<String, String>> getExamplesFromScenarioOutline(Path featureFile, String scenarioName) throws IOException {
        List<String> lines = Files.readAllLines(featureFile);
        boolean foundScenario = false;
        boolean foundExamples = false;
        List<String> headers = new ArrayList<>();
        List<Map<String, String>> exampleData = new ArrayList<>();

        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("Scenario Outline:") && line.contains(scenarioName)) {
                foundScenario = true;
                continue;
            }
            if (foundScenario) {
                if (line.startsWith("Scenario:") || line.startsWith("Feature:")) {
                    break; // Stop when a new scenario starts
                }
                if (line.startsWith("Examples:")) {
                    foundExamples = true;
                    continue;
                }
                if (foundExamples) {
                    if (line.startsWith("|")) {
                        List<String> values = Arrays.asList(line.split("\\|"));
                        values = values.stream().map(String::trim).filter(s -> !s.isEmpty()).toList();

                        if (headers.isEmpty()) {
                            headers = values.stream()
                                    .map(header -> "<" + header + ">") // Ensure placeholders retain "< >"
                                    .toList();
                        } else {
                            Map<String, String> rowData = new HashMap<>();
                            for (int i = 0; i < headers.size(); i++) {
                                rowData.put(headers.get(i), values.get(i)); // Assign values correctly
                            }
                            exampleData.add(rowData);
                        }
                    }
                }
            }
        }
        return exampleData;
    }

    public static List<List<String>> getStepsFromScenario(String scenarioName) throws IOException {
        List<Path> featureFiles = getFeatureFiles();
        for (Path featureFile : featureFiles) {
            List<List<String>> scenarioSteps = extractStepsFromFeature(featureFile, scenarioName);
            if (!scenarioSteps.isEmpty()) {
                return scenarioSteps;
            }
        }
        return Collections.emptyList(); // No scenario found
    }

    public static List<Path> getFeatureFiles() throws IOException {
        try (var paths = Files.walk(Paths.get("src/test/resources/Snippet"))) {
            return paths.filter(path -> {
                boolean isFile = Files.isRegularFile(path);
                return isFile && path.toString().endsWith(".feature");
            }).toList();
        }
    }

    private static List<List<String>> extractStepsFromFeature(Path featureFile, String scenarioName) throws IOException {
        List<String> lines = Files.readAllLines(featureFile);
        boolean isScenarioOutline = false;
        boolean foundScenario = false;
        List<String> stepTemplate = new ArrayList<>();
        List<Map<String, String>> exampleData = new ArrayList<>();

        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();

            // Detect scenario start
            if (line.startsWith("Scenario:") && line.contains(scenarioName)) {
                foundScenario = true;
                isScenarioOutline = false;
                continue;
            } else if (line.startsWith("Scenario Outline:") && line.contains(scenarioName)) {
                foundScenario = true;
                isScenarioOutline = true;
                continue;
            }

            // Process scenario steps
            if (foundScenario) {
                if (line.startsWith("Scenario:") || line.startsWith("Feature:")) {
                    break; // Stop at next scenario or feature
                }
                if (line.matches("^(Given|When|Then|And)\\s+.*")) {
                    stepTemplate.add(line);
                }
            }

            // Extract Example Table Data
            if (isScenarioOutline && line.startsWith("Examples:")) {
                i++; // Move to the header row
                List<String> headers = extractTableRow(lines.get(i++));
                while (i < lines.size() && lines.get(i).trim().startsWith("|")) {
                    List<String> values = extractTableRow(lines.get(i++));
                    Map<String, String> rowData = new HashMap<>();
                    for (int j = 0; j < headers.size(); j++) {
                        rowData.put("<" + headers.get(j) + ">", values.get(j)); // Keep placeholder format
                    }
                    exampleData.add(rowData);
                }
                break;
            }
        }

        if (!isScenarioOutline) {
            return List.of(stepTemplate); // Return steps as a single list (non-outline scenario)
        }

        // Generate step instances with example values
        List<List<String>> scenarioInstances = new ArrayList<>();
        for (Map<String, String> row : exampleData) {
            List<String> scenarioInstance = new ArrayList<>();
            for (String step : stepTemplate) {
                scenarioInstance.add(replacePlaceholders(step, row));
            }
            scenarioInstances.add(scenarioInstance);
        }
        return scenarioInstances;
    }

    private static List<String> extractTableRow(String line) {
        return Arrays.stream(line.split("\\|"))
                .map(String::trim)
                .filter(cell -> !cell.isEmpty()) // Removes any accidental empty entries
                .toList();
    }

    private static String replacePlaceholders(String step, Map<String, String> exampleValues) {
        for (Map.Entry<String, String> entry : exampleValues.entrySet()) {
            step = step.replace(entry.getKey(), entry.getValue());
        }
        return step;
    }

    public static DataTable getDataTableFromFeature(String gherkinSentence) throws IOException {
        String cleanedStep = cleanGherkinStep(gherkinSentence);
        List<Path> featureFiles = getFeatureFiles();

        for (Path featureFile : featureFiles) {
            DataTable table = extractDataTableFromFeature(featureFile, cleanedStep);
            if (table != null) {
                return table;
            }
        }
        return null; // Return null if no DataTable found
    }

    private static String cleanGherkinStep(String step) {
        return step.replaceAll("^(Given|When|Then|And)\\s+", "").trim();
    }

    private static DataTable extractDataTableFromFeature(Path featureFile, String cleanedStep) throws IOException {
        List<String> lines = Files.readAllLines(featureFile);
        boolean foundStep = false;
        List<List<String>> tableRows = new ArrayList<>();

        for (String line : lines) {
            line = line.trim();
            if (cleanGherkinStep(line).equalsIgnoreCase(cleanedStep)) {
                foundStep = true;
                continue;
            }
            if (foundStep) {
                if (line.startsWith("|")) {
                    List<String> row = Arrays.asList(line.replace("|", "").trim().split("\\s*\\|\\s*"));
                    tableRows.add(row);
                } else {
                    break; // Stop if we reach another step or section
                }
            }
        }
        return tableRows.isEmpty() ? null : DataTable.create(tableRows);
    }
}