package workDirectory.stepDefinitions;

import builds.snippet.GherkinDataTableExtractor;
import builds.snippet.GherkinStepRunner;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.Before;
import io.cucumber.java.ParameterType;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

public class CommonStepDefinitions extends CommonMethods{

    private final GherkinStepRunner stepRunner = new GherkinStepRunner(List.of(CommonStepDefinitions.class));

    private Scenario currentScenario; // Store the scenario instance

    @Before
    public void beforeScenario(Scenario scenario) {
        this.currentScenario = scenario; // Capture the scenario instance before each scenario runs
    }

    @When("run snippet scenario {string}")
    public void runSnippetScenario(String scenarioName) throws Exception {
        List<Path> featureFiles = GherkinDataTableExtractor.getFeatureFiles();
        boolean isScenarioExecuted = false;

        for (Path featureFile : featureFiles) {
            List<Map<String, String>> exampleDataList = GherkinDataTableExtractor.getExamplesFromScenarioOutline(featureFile, scenarioName);
            List<List<String>> scenarioSteps = GherkinDataTableExtractor.getStepsFromScenario(scenarioName);

            if (!exampleDataList.isEmpty()) {
                for (Map<String, String> exampleData : exampleDataList) {
                    // Create a separate fresh list for each example row
                    List<List<String>> scenarioStepsForExample = new ArrayList<>();

                    for (List<String> steps : scenarioSteps) {
                        List<String> updatedSteps = new ArrayList<>();
                        for (String step : steps) {
                            updatedSteps.add(replaceExamplePlaceholders(step, exampleData));
                        }
                        scenarioStepsForExample.add(updatedSteps);
                    }

                    String formattedExampleData = exampleData.entrySet().stream()
                            .map(entry -> entry.getKey().replaceAll("[<>]", "") + ": " + entry.getValue())
                            .collect(Collectors.joining(", "));

                    currentScenario.log("🔹 Running Scenario: **" + scenarioName + "** with Example Data: {" + formattedExampleData + "}");

                    try {
                        // Execute only the steps for the current example
                        executeScenarioWithExampleData(scenarioStepsForExample, exampleData);
                    } catch (Exception e) {
                        currentScenario.log("❌ Scenario Failed: **" + scenarioName + "** with Example Data: {" + formattedExampleData + "} | Error: " + e.getMessage());
                        throw e;
                    }
                }
                return; // Exit after executing all examples
            }
        }

        // If no example data, execute normally
        if (!isScenarioExecuted) {
            List<String> steps = GherkinDataTableExtractor.getStepsFromScenario(scenarioName).get(0);
            currentScenario.log("🔹 Running Scenario: **" + scenarioName + "** (No Example Data)");

            try {
                executeScenarioWithExampleData(List.of(steps), new HashMap<>());
            } catch (Exception e) {
                currentScenario.log("❌ Scenario Failed: **" + scenarioName + "** (No Example Data) | Error: " + e.getMessage());
                throw e;
            }
        }
    }

    private void executeScenarioWithExampleData(List<List<String>> scenarioStepsForExample, Map<String, String> exampleData) throws Exception {
        for (List<String> steps : scenarioStepsForExample) {
            for (String step : steps) {
                String replacedStep = replaceExamplePlaceholders(step, exampleData);
                DataTable dataTable = GherkinDataTableExtractor.getDataTableFromFeature(replacedStep);

                try {
                    stepRunner.executeStep(replacedStep, dataTable);
                    currentScenario.log("✅ Passed: " + replacedStep);
                } catch (Exception e) {
                    currentScenario.log("❌ Failed: " + replacedStep + " | Error: " + e.getMessage());
                    throw e;
                }
            }
        }
    }

    private String replaceExamplePlaceholders(String step, Map<String, String> exampleData) {
        for (Map.Entry<String, String> entry : exampleData.entrySet()) {
            String placeholder = entry.getKey();  // e.g., "<username>"
            String value = entry.getValue();      // e.g., "autouat1"

            // Ensure placeholder format is correct
            step = step.replace(placeholder, "\"" + value + "\"");
        }
        return step;
    }

    // Adding addition parameter for gherkin
    @ParameterType("true|false")
    public Boolean booleanType(String value) {
        return Boolean.parseBoolean(value);
    }

    @And ("if {int} is bigger than {int}")
    public void ifNumberIsBiggerThanNumber(int firstValue, int secondValue){
       addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Arrays.asList(firstValue,secondValue));
    }

    @And ("if {int} is smaller than {int}")
    public void ifNumberIsSmallerThanNumber(int firstValue, int secondValue){
        addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Arrays.asList(firstValue,secondValue));
    }

    @And ("if {string} is not visible")
    public void ifElementIsNotVisible(String elementName){
        addStatementCounter(new Object(){}.getClass().getEnclosingMethod().getName(), Collections.singletonList(elementName));
    }

    @And("end statement")
    public void endIfStatement(){
        endIf();
    }

    @Then("print from data table without header below")
    public void printFromDataTableWithoutHeaderBelow(DataTable dataTable) {
        System.out.println(dataTable.cells());
    }

    @Then("print from data table with header below")
    public void printFromDataTableWithHeaderBelow(DataTable dataTable) {
        System.out.println(dataTable.cells());
    }

    @Then("print string {string} {double} {booleanType}")
    public void printString(String arg0, Double arg1, Boolean arg2) {
        if(toExecute.get()){
            System.out.println(arg0);
            System.out.println(arg1);
            System.out.println(arg2);
        }

    }

    @Given("I launch the Mobile Simulator {string}")
    public void iLaunchTheMobileSimulator(String variableURL) {
        if(toExecute.get()){
            mobileSetup(variableURL);
        }
    }

    @Given("I navigate mobile browser to {string}")
    public void iNavigateMobileBrowserTo(String URL) {
        if(toExecute.get()) {
            navigateToURL(URL);
        }
    }

    @When("I set text {string} into {string}")
    public void iSetTextInto(String value, String elementName) {
        if(toExecute.get()){
            setText(value, elementName);
        }
    }

    @And("take screenshot")
    public void takeAScreenshot() {
        if(toExecute.get()){
           takeScreenshot();
        }
    }

    @Given("I launch {string} browser and navigate to {string}")
    public void iLaunchTheBrowserAndNavigateTo(String browserType, String URL) {
        if(toExecute.get()){
           browserSetup(browserType, URL);
        }
    }

    @When("I click {string}")
    public void iClick(String elementName) {
        if(toExecute.get()){
           click(elementName);
        }
    }

    @Then("I verify element {string} is visible")
    public void iVerifyElementIsVisible(String elementName) {
        if(toExecute.get()) {
            verifyElementVisible(elementName);
        }
    }

    @Then("I get text from {string} and set into variable {string}")
    public void iGetTextFromAndSetIntoVariable(String elementName, String variableName) {
        if(toExecute.get()) {
            getTextFromAndSetIntoVariable(elementName, variableName);
        }
    }

    @Then("I verify text {string} is equals to variable {string}")
    public void iVerifyTextIsEqualsToVariable(String expectedText, String variableName) {
        if(toExecute.get()) {
            verifyTextIsEqualsToVariable(expectedText, variableName);
        }
    }
}
